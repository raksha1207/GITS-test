import os
import sys


def gits_hello_world(args):
    """
    Function that prints hello message
    to user console
    """
    print("Hello from GITS Commandline Tools")
