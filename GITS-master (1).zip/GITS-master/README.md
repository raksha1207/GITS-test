
# GITS 
### GIT Simplified

![GitHub](https://img.shields.io/github/license/amolgautam25/GITS)
![GitHub](https://img.shields.io/badge/language-python-blue.svg)
[![DOI](https://zenodo.org/badge/295480790.svg)](https://zenodo.org/badge/latestdoi/295480790)

[![](https://img.youtube.com/vi/cMcftHMtIZ4/0.jpg)](https://youtu.be/cMcftHMtIZ4 "GITS demo")



This repository is made for CSC 510 Software Engineering Course at NC State University.

Group 17 Team Members: 

Amol Gautam  
Sneha Kumar  
Sreeraksha Mavinhally Sreekantha  
Srujana Rachakonda  
Tanay Agarwal
