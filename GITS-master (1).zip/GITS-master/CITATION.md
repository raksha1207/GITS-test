Cite as

Tanay Agrawal, Amol Gautam, & Sneha192. (2020, August 16). amolgautam25/se20_group17: Initial Commit (Version v1). Zenodo.https://doi.org/10.5281/zenodo.4029213

```
@article{amolgautam25:GITS,
  title     = {se20_group17: Initial Commit (Version v1)},
  DOI       = {10.5281/zenodo.4029213}, 
  author    = {Tanay Agrawal, Amol Gautam, & Sneha192}, 
  publisher = {Zenodo}, 
  year      = {2020}, 
  month     = {August}
}
```
